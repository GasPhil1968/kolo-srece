NIGHT LATCH - a noir point-and-click detective adventure (Brackwater, 1951)

TO PLAY: unzip the folder, then double-click index.html. It runs in your browser (Chrome, Edge,
Firefox or Safari), offline, with nothing to install. Saves are kept by the browser.

Left-click: walk / use / take / talk.  Right-click: look.  Click an item, then a target: use it.
N notebook, M map, H hint, Esc menu, Tab show hotspots, F fullscreen.
